package com.ananna.firebaseconnect.helper;

/**
 * Created by Lenovo on 11/14/2017.
 */

public class EndPoints {
    public static final String GETDATA = "https://openlibrary.org/api/books?bibkeys=ISBN:9780307277671&jscmd=data&format=json";
}
